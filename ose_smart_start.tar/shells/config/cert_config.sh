#/bin/bash
#
# This config file set CN name. The CN will looks like : ${host}.${env}.${subdomain}
# Example : healthcheck-https.pnp.cloudapps.ao.dcn
# ${EVN} and ${SUBDOMAIN} are in ose_config.sh
host=heatlthcheck-https

