export base_images=" ose-sti-builder ose-docker-builder ose-deployer ose-haproxy-router ose-docker-registry ose-pod"
export default_registry="registry.access.redhat.com/openshift3"
export new_docker_registry_url="192.168.200.108:5000"
export version="v3.1.1.6"

