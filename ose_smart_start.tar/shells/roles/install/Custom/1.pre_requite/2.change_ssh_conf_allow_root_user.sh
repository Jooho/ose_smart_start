#!/bin/bash

if [ \`id -u\` != 0 ]; then echo "ERROR: You need to be root.  Exiting"; exit 9; fi

# Allow sudo NOPASSWD for wheel (reverse this after the installation is complete
sed -i -e 's/^%wheel/##%wheel/g' /etc/sudoers
sed -i -e 's/^# %wheel/%wheel/g' /etc/sudoers
if [ ! -f ~/.ssh/id_rsa.pub ]; then echo | ssh-keygen -b2048 -trsa -N ''; fi

# oseadmin auth_keys should be sufficient to allow the install node to connect
cp ~oseadmin/.ssh/authorized_keys /root/.ssh/authorized_keys
sed -i -e 's/^PermitRootLogin no/PermitRootLogin yes/g' /etc/ssh/sshd_config
cp /etc/ssh/sshd_config /etc/ssh/sshd_config-\`date +%F%H%M\`
systemctl restart sshd
exit 0
