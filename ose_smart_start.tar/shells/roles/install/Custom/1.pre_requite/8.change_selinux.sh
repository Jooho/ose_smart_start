#SELinux (enable virt_use_nfs/virt_sandbox_use_nfs)¬
for HOST in `cat $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q root@$HOST "setsebool -P virt_use_nfs=true; setsebool -P virt_sandbox_use_nfs 1"; done¬
