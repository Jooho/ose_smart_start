#!/bin/bash
SATELLITE='aosat6-e-app001'
DOMAIN='ctho.asbn.gtwy.dcn'
ORGANIZATION='ose-config'
# subscription-manager list --available --all | grep -n5 EPEL
EPEL_POOL_ID="8a22934550f222f10150f23244240002"

rm /etc/yum.repos.d/local.repo
mv /etc/sysconfig/rhn/systemid /etc/sysconfig/rhn/.systemid 
subscription-manager clean
yum -y localinstall http://\${SATELLITE}.\${DOMAIN}/pub/katello-ca-consumer-latest.noarch.rpm
subscription-manager register --org="\${ORGANIZATION}" --environment="Library" --username='joshib' --password='Passw0rd'
--release=7.2 --auto-attach --force
subscription-manager repos --disable="*" --enable rhel-7-server-rpms --enable rhel-7-server-satellite-tools-6.1-rpms
--enable=rhel-7-server-extras-rpms --enable=rhel-7-server-ose-3.1-rpms
yum -y install katello-agent
katello-package-upload
yum -y update
