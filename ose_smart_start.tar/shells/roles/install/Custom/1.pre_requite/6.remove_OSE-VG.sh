cp /etc/fstab /etc/fstab.`date +%F-%H%M`
umount /ose01
sed -i -e '/ose/d' /etc/fstab
mount -a
lvremove -y /dev/mapper/vg_ose-lv_ose01
vgremove -f vg_ose
echo "d
w
" | fdisk /dev/sdb; partprobe
