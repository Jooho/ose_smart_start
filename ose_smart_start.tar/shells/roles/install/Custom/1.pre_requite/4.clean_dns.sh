echo "DOMAIN=\"sndg.gtwy.dcn asbn.gtwy.dcn uscourts.gov ao.dcn gtwy.dcn ctho.asbn.gtwy.dcn\"" >> /etc/sysconfig/network-scripts/ifcfg-primary
echo "DNS1=\"156.119.163.10\"" >> /etc/sysconfig/network-scripts/ifcfg-primary
echo "DNS2=\"156.119.183.10\"" >> /etc/sysconfig/network-scripts/ifcfg-primary
