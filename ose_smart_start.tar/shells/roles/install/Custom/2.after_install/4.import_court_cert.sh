#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
# Purpose: no idea....have to ask to James 
#         



## Import Courts Cert on OC client machine
wget http://www.ssl.ao.dcn/US_COURTS_ROOT_CA.crt 
openssl x509 -inform DER -in US_COURTS_ROOT_CA.crt -outform PEM -out
/etc/pki/ca-trust/source/anchors/US_COURTS_ROOT_CA.pem
wget http://www.ssl.ao.dcn/US_COURTS_Private_SSL_CA.crt 
openssl x509 -inform DER -in US_COURTS_Private_SSL_CA.crt -outform PEM -out
/etc/pki/ca-trust/source/anchors/US_COURTS_Private_SSL_CA.pem
update-ca-trust

