i#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
# Purpose: Execute 7-1.config_rsyslog_logrotate.sh on All VMs.

# Included scripts:
#
#  - 7-1.config_rsyslog_logrotate.sh
#   Description :
#      Redirect logs which contains specific word "openshift" and "docker" to file
#   Execute Host:
#        All VMs except ETCD nodes.
#   Config file: ose_config.sh


for HOST in `egrep -v 'mgt007|mgt008|mgt009' $CONFIG_PATH/${host_file} | awk '{ print $1 }' `
do
   if [[ ! -e ${ose_temp_dir} ]]; then
   	ssh -q root@$HOST "mkdir -p ${ose_temp_dir}"
   fi
   scp ./7-1.config_rsyslog_logrotate.sh  root@$HOST:${ose_temp_dir}/.
   ssh -q root@$HOST "sh ${ose_temp_dir}/7-1.config_fsyslog_logrotate.sh"
done
