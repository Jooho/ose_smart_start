#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
# Purpose: Open necessary ports (iptables)
#
# Question : how to make it persistently

# Open port 1936 which is used by haproxy statistics
for HOST in `egrep -v 'mgt004|mgt005|mgt006|mgt007|mgt008|mgt009' $CONFIG_PATH/${host_file} | awk '{ print $1 }' `
do
    ssh -q root@$HOST "-A OS_FIREWALL_ALLOW -p tcp -m state --state NEW -m tcp --dport 1936 -j ACCEPT"
    ssh -q root@$HOST "-A OS_FIREWALL_ALLOW -p udp -m state --state NEW -m udp --dport 1936 -j ACCEPT"
done
