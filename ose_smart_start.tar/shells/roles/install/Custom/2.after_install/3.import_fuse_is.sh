#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
# Purpose: Import Fuse Image

#oc create -n openshift -f https://raw.githubusercontent.com/jboss-fuse/application-templates/master/fis-image-streams.json
ssh -q root@${ose_cli_operation_vm} "oc create -n openshift -f /usr/share/openshift/examples/xpaas-streams/fis-image-streams.json"
