#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.25
# Purpose: Check whether VMs are ready to install
#          Validate DNS / Validate yum repolist / Validate docker storage / Validate persistent volume


# Included scripts:
#
#  - validation_dns_lookup.sh
#   Description :
#       In order to install openshift, all VMs hostname/lb should be resovled by DNS (wildcard${subdomain} is optional)
#       This script check DNS entries.       
#   Execute Host: 
#        All VMs

#  - validation_yum_repolist.sh
#   Description :
#       In order to install openshift, rhel7, rhel7 extra, ose3 repositories should be attached to all VMs.
#       This script check YUM repositories.       
#   Execute Host: 
#        All VMs

#  - validation_docker_storage.sh
#   Description :
#       Using docker storage is strongly recommended so this script check it is already configured or not. However it is not mandatory.
#   Execute Host: 
#        All VMs

#  - validation_persistent_vol.sh
#   Description :
#       This script check NFS server connectivity and GUID for using PV
#   Execute Host: 
#        All VMs

. $CONFIG_PATH/ose_config.sh
cd $HOME_PATH/
tar cvf ./ose_smart_start.tar ./
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`;
do
  ssh -q oseadmin@${HOST} "mkdir -p ${ose_temp_dir}/ose_smart_start"
  scp ./ose_smart_start.tar oseadmin@${HOST}:${ose_temp_dir}/ose_smart_start/.
  ssh -t -q oseadmin@${HOST} "tar xvf ${ose_temp_dir}/ose_smart_start/ose_smart_start.tar"

  echo "======================================================"
  echo "=================== Validate oseadmin@${HOST} ==================="
  echo "======================================================"

  echo ""
  echo "***** validation_dns_lookup on oseadmin@${HOST} ******"
  echo ""
  #scp ./validation_dns_lookup.sh oseadmin@${HOST}:${ose_temp_dir}/.
  ssh -q oseadmin@${HOST} "sh source ${ose_temp_dir}/ose_smart_start/getReady.sh;cd ${ose_temp_dir}/ose_smart_start/shells/roles/validation/pure_vm_check/validation_dns_lookup.sh"
  read
  
  echo ""
  echo "***** validation_yum_repolist on oseadmin@${HOST} ******"
  echo ""
  scp ./validation_yum_repolist.sh oseadmin@${HOST}:${ose_temp_dir}/.
  ssh -q oseadmin@${HOST} "sh ${ose_temp_dir}/validation_yum_repolist.sh" 
  read 
  
  echo ""
  echo "***** validation_docker_storage on oseadmin@${HOST} ******"
  echo ""
  scp ./validation_docker_storage.sh oseadmin@${HOST}:${ose_temp_dir}/.
  ssh -q oseadmin@${HOST} "sh ${ose_temp_dir}/validation_docker_storage.sh" 
  read 

  echo ""
  echo "***** validation_persistent_vol on oseadmin@${HOST} ******"
  echo ""
  scp ./validation_persistent_vol.sh oseadmin@${HOST}:${ose_temp_dir}/.
  ssh -q oseadmin@${HOST} "sh ${ose_temp_dir}/validation_persistent_vol.sh "
  read 
done
