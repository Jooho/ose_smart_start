. ./ose_config.sh 
password=redhat
echo $all_ip
tar -cvf validation.tar ./
for node in $all_hosts
do
  echo " "
  echo "Test DNS on $node"
  echo " "
  cp ./validation.tar root@$node:/root 
  sshpass -p $password tar xvf ./validation.tar root@$host
  read
done

