#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
# Purpose: Replace default certificate which is provided by Openshift to custom cert for web console.
#          This script set up necessary environment in order to install Openshift


# Included scripts:
#
#  - 1.generate_self_signed_cert_simple.sh
#   Description :
#       Generate private key/csr/crt file but it needs csr file for request to get custom cert.
#   Execute Host:
#        ${ose_cli_operation_vm}



./1-2.generate_self_signed_cert_simple.sh

# Back master-config.yaml
# Copy the *.cer and *.key to /etc/origin/master directory on ALL master nodes¬
for HOST in `egrep 'mgt004|mgt005|mgt006' $CONFIG_PATH/${host_file} | awk '{ print $1 }' ` 
do  
    ssh -q root@$HOST "cp /etc/origin/master/master-config.yaml /etc/origin/master/master-config.yaml-`date +%F-%H%M`_before_change_webconsole_cert"

    scp ${host}.${env}.${subdomain}.key root@$HOST:/etc/origin/master/.
    scp ${host}.${env}.${subdomain}.csr root@$HOST:/etc/origin/master/.
    #scp ${host}.${env}.${subdomain}.crt /etc/origin/master/. # crt file have be provided by client
done

# There are 2 locations that need the following...
# At the top of the config file, update ^assetConfig
# At the bottom of the config file, update ^servingInfo 
#   maxRequestsInFlight: 500  << BETWEEN HERE
#  namedCertificates:
#  - certFile: api_pnp_cloudapps_ao_dcn.crt
#    keyFile: api_pnp_cloudapps_ao_dcn.key
#    names:
#    - "api.pnp.cloudapps.ao.dcn"
#  requestTimeoutSeconds: 3600  << AND HERE
# Update masterPublicURL, assetConfig.publicURL, and oauthConfig.assetPublicURL
# 
cat << EOF 

** Update atomci-openshift-master-api.yaml on all master nodes **
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   maxRequestsInFlight: 500  << BETWEEN HERE
  namedCertificates:
  - certFile: api_pnp_cloudapps_ao_dcn.crt
    keyFile: api_pnp_cloudapps_ao_dcn.key
    names:
    - "api.pnp.cloudapps.ao.dcn"
  requestTimeoutSeconds: 3600  << AND HERE
 Update masterPublicURL, assetConfig.publicURL, and oauthConfig.assetPublicURL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

** Check command 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
egrep 'URL|api.pnp|api_pnp' master-config.yaml
  logoutURL: ""
  masterPublicURL: https://api.pnp.cloudapps.ao.dcn:8443
  publicURL: https://api.pnp.cloudapps.ao.dcn:8443/console/
  - certFile: api_pnp_cloudapps_ao_dcn.crt
    keyFile: api_pnp_cloudapps_ao_dcn.key
    - "api.pnp.cloudapps.ao.dcn"
masterPublicURL: https://api.pnp.cloudapps.ao.dcn:8443
  assetPublicURL: https://api.pnp.cloudapps.ao.dcn:8443/console/
  masterPublicURL: https://aoappd-cluster.pnp.cloudapps.ao.dcn:8443
  masterURL: https://aoappd-cluster.pnp.cloudapps.ao.dcn:8443
  - certFile: api_pnp_cloudapps_ao_dcn.crt
    keyFile: api_pnp_cloudapps_ao_dcn.key
    - "api.pnp.cloudapps.ao.dcn"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EOF


# Restart atomic-openshift-master-api
export correct_answer="false"
while [ $correct_answer == "false" ]
do
	echo "Have you update configuration on all Master Nodes?(y/n)"
	read update_master_configuration
	if [[ $update_master_configuration == "y" ]]; then
	for HOST in `egrep 'mgt004|mgt005|mgt006' $CONFIG_PATH/${host_file} | awk '{ print $1 }' ` 
	do  
		echo "Restarting master server : $HOST"
		ssh -q root@$HOST "systemctl restart atomic-openshift-master-api"
	done
	correct_answer=true
else
	echo "Please choose y or n only. If you don't update master-config.yaml, you have to do it before typing 'y'"
fi
# Test
echo | openssl s_client -connect ${host}.${env}.${subdomain}:8443 -servername ${host}.${env}.${subdomain} | grep CN

#  The curl will fail until you import the Customer Certs
curl -v https://${host}.${env}.${subdomain}:8443
