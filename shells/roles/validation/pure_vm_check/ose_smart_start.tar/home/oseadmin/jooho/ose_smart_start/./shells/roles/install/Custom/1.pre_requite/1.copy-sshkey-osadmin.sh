for HOST in `cat hosts.pnp | awk '{ print $1 }'`; do ssh-copy-id -oStrictHostKeyChecking=no $HOST; done
for HOST in `cat hosts.pnp | awk '{ print $1 }'`; do ssh -q $HOST "uptime"; done
for HOST in `cat hosts.pnp | awk '{ print $1 }'`; do scp ~/.bashrc ${HOST}: ; done
for HOST in `cat hosts.pnp | awk '{ print $1 }'`; do scp ~/.bash_profile ${HOST}: ; done
