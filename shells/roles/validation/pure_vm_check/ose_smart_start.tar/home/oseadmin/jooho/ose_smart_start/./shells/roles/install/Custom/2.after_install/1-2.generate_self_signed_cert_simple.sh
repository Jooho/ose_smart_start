#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.23
#  Purpose: Generate private key/csr/crt file
#            This script is simpler way than generate_self_signed_cert.sh
#  Config file : $CONFIG_PATH/cert_config.sh
#               The CN will looks like : ${host}.${env}.${subdomain}
#               Example : healthcheck-https.pnp.cloudapps.ao.dcn
#  NOTICE :
#  You should use this when you submit the request (via the web)
#  http://dts-tso.jdcwin.jdc.ao.dcn/PWA/OSE%20Pilot/Project%20Documents/docs/OSEv3%20-%20Certificate%20Management.docx
#  https://certmanager.websecurity.symantec.com/mcelp/enroll/index?jur_hash=937466f627ad45d0c2033c4d4a94c947
#  challengePasssword      = 'RedH@tOs3'
#
#  Example actual command to create csr file to request certificate signed by client:
# openssl req -new -newkey rsa:2048 -nodes -out api_sbx_cloudapps_ao_dcn.csr -keyout api_sbx_cloudapps_ao_dcn.key -subj "/C=US/ST=District of Columbia/L=Washington/O=Administrative Office of the United States Courts/OU=Administrative Office of the United States Courts/CN=api.sbx.cloudapps.ao.dcn"
#
# TODO: probably should add something to make sure file does not already exist.  I.e. don't overwrite an existing key,
# or the thing is invalid.

# This one liner is all you need
if [[ -e ${host}.${env}.${subdomain}.key ]] || [[ -e ${host}.${env}.${subdomain}.csr ]] || [[ -e ${host}.${env}.${subdomain}.crt ]]; then
  echo "There are already generaged files so please check it first.. don't want to mess up"
  exit 9
else
  openssl req -new -newkey rsa:2048 -nodes -out ${host}_${env}_cloudapps_ao_dcn.csr -keyout ${host}_${env}_cloudapps_ao_dcn.key -subj "/C=US/ST=District of Columbia/L=Washington/O=Administrative Office of the United States Courts/OU=Administrative Office of the United States Courts/CN=${host}.${env}.cloudapps.ao.dcn"
  openssl req -text -noout -in ${host}_${env}_cloudapps_ao_dcn.csr 
  openssl x509 -req -days 1095 -in ${host}.${env}.${subdomain}.csr -signkey ${host}.${env}.${subdomain}.key -out ${host}.${env}.${subdomain}.crt -extensions v3_req -extfile ${host}.${env}.${subdomain}.openssl-conf# openssl pkcs12 -export -in san_${env}_cloudapps_ao_dcn.crt -inkey san_${env}_cloudapps_ao_dcn.key -out san_${env}_cloudapps_ao_dcn.p1

  exit 0
fi
