# Install ansible package which is conainted atomic-openshift-utils package.
yum –y install atomic-openshift-utils

# This should be moved to Validation part
for HOST in `egrep -v 'mgt007|mgt008|mgt009' $CONFIG_PATH/$host_file | awk '{ print $1 }' ` 
do 
  ssh -q root@$HOST "uname -n; yum list docker-1.8.2"
done

# Cofigure Docker Nodes
cat << EOF > ./my-docker-storage-setup
if [ -b /dev/sdb ] 
then 
  /usr/bin/docker-storage-setup 
  systemctl stop docker
  rm -rf /var/lib/docker/*  
  systemctl start docker
  systemctl enable docker
  systemctl status docker
fi
EOF

# Run the following everywhere but the ETCD nodes...
for HOST in `egrep -v 'mgt007|mgt008|mgt009' $CONFIG_PATH/$host_file | awk '{ print $1 }' ` 
do  
    echo "########## ############### ###############"
    echo "NOTE: working on $HOST"
    scp ./my-docker-storage-setup root@${HOST}:my-docker-storage-setup
    ssh root@${HOST} "yum -y install docker-1.8.2"
    ssh root@${HOST} "sh ./my-docker-storage-setup"
    echo
done

# Mark sure that host keys are working before you start the Ansible playbook
cat << EOF > ~/.ansible.cfg
[defaults] 
log_path=~/.ansible.log
EOF

# Check 
# Question : what is this for?
for HOST in `cat $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q root@$HOST "uptime"; done

ls ${inventory_dir_path}/${ansible_hosts}

## Example remote command
#for HOST in `grep mgt $CONFIG_PATH/$host_file | awk '{ print $1 }'`
#do
#  ssh root@$HOST bash -c '"
#uptime
#"'
#done


