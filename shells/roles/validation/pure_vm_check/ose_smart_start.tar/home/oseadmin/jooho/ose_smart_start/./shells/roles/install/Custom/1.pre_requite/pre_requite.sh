#!/bin/bash
#
#  Author: Jooho Lee(ljhiyh@gmail.com)
#    Date: 2016.05.20
# Purpose: Pre-requite 
#          This script set up necessary environment in order to install Openshift


# Included scripts:
#
#  - 1.copy-sshkey-osadmin.sh
#   Description :
#       Copy non-root user ssh key to all environment because the environment does not allow to connect with root user.
#   Execute Host: 
#        ansible hosts

#  - 2.change_ssh_conf_allow_root_user.sh 
#   Description :
#       Change ssh configuration to allow root to access on all vms   
#   Execute Host :
#       All VMs

#  - 3.generate_std_bash_profile.sh
#   Description :
#       Generate standard bashrc bash_profile
#   Execute Host :
#       All VMs
#
#  **Notice**
#     If you have not configured the ssh auth for oseadmin to root, 
#            ***** You should NOT proceed ****
#
#  - 4.clean_dns
#   Description :
#       Add DNS servers which OSE should use and these servers are needed to install OSE as well. (This script update ifcfg-primary about search-name and DNS)
#   Execute Host:
#       All VMs
#
#  - 5.satellite_subscription.sh
#   Description :
#       This script will install katello-package and try to register host to satellite using subscription-manger 
#   Execute Host:
#       All VMs
#  
#  - 6.remove_OSE-VG.sh
#   Description :
#       The VM that is provided by client have defuault block device 'sdb' which called vg_ose. However, to split the block-device for several object such as docker/log/etcd, this script remove it
#   Execute Host:
#       All VMs
#
#  - 7.storage_setup_functions.sh
#   Description :
#      Each host have to have different lvm storage size and count according to a host role.
#      ETCD : ETCD db  - /var/lib/etcd 200G
#      Master : OSE Meta data - /var/lib/openshift  40%
#               Docker storage - sdb2   60%
#      Node : Docker storage - sdb2 100%
#   Execute Host:
#       All VMs
#    Question : why node does not have separated storage for OSE meta data             
##############################################################################

. $CONFIG_PATH/ose_config.sh


##############################  COPY SSH KEY  ################################


# Be prepared to enter the oseadmin password when sudo requests it
# os3@dm1n

./1.copy-sshkey-osadmin.sh

# Copy the 1,2 scripts to the host(s) then execute it
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do scp ./2.change_ssh_conf_allow_root_user.sh ${HOST}: ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do scp ./3.generate_std_bash_profile.sh ${HOST}: ; done

# Execute #2, #3 script on each vm
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ssh -q -t ${HOST} '/usr/bin/sudo su - -c "sh ~oseadmin/2.change_ssh_conf_allow_root_user.sh"' ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ssh -q -t ${HOST} '/usr/bin/sudo su - -c "sh ~oseadmin/3.generate_std_bash_profile.sh"' ; done

# Now test - you should no longer need a password
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q -t ${HOST} '/usr/bin/sudo su - -c "grep oseadmin /etc/shadow"' ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q -t root@${HOST} "grep oseadmin /etc/shadow"; done



###############################  Clean DNS   ############################

for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do scp ./4.cleanup_DNS.sh ${HOST}: ; done¬
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ssh root@${HOST} "sh ~oseadmin/4.cleanup_DNS.sh; systemctl restart network" ; done¬
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ssh ${HOST} "cat /etc/resolv.conf" ; done¬


####################### Subscribe hosts to Satellite 6 ##############
# (./5.scp satellite_subscription.sh)
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ./5.scp satellite_subscription.sh ${HOST}: ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $2 }'`; do ssh -q root@${HOST} "sh ~oseadmin/5.satellite_subscription.sh" ; done


############################ STORAGE ##############################

# (6.remove_OSE-VG.sh) Remove the vg_ose from sdb
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do scp 6.remove_OSE-VG.sh ${HOST}: ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q root@${HOST} "sh ~oseadmin/6.remove_OSE-VG.sh" ; done
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; do ssh -q root@${HOST} "hostname; parted -s /dev/sdb print" ; done


# (7.storage_setup_functions.sh) configure storage according to node role.
. ./7.storage_setup_functions.sh

# CONFIGURE THE DEVICE DEPENDING ON WHAT HOST IT IS
for HOST in `grep -v \# $CONFIG_PATH/$host_file | awk '{ print $1 }'`; 
do
  case $HOST in 
    *mgt004*|*mgt005*|*mgt006*)
      echo "NOTE: found $HOST"
      storage_master
    ;;
    *mgt007*|*mgt008*|*mgt009*)
      echo "NOTE: found $HOST"
      storage_etcd
    ;;
    *nde*)
      echo "NOTE: found $HOST"
      storage_compute
    ;;
  esac
  scp ./do_storage.sh $HOST:
  ssh root@${HOST} "sh ~oseadmin/do_storage.sh"
done


################### SELinux Configuration ##################
./8.change_selinux.sh

#################### Ansible / Docker setup #################
./9.config_ansible_docker.sh

################### Install OSE !!!!!    ##################
echo " "
echo "Now we are ready to install Openshift, please execute this command"
echo "ansible-playbook /usr/share/ansible/openshift-ansible/playbooks/byo/config.yml -i ${inventory_dir_path}/${ansible_hosts}"
