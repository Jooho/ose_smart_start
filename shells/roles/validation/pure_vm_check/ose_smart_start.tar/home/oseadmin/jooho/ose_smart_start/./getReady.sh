export HOME_PATH=$PWD
export CONFIG_PATH=${HOME_PATH}/shells/config
export ANSIBLE_PATH=${HOME_PATH}/ansible
