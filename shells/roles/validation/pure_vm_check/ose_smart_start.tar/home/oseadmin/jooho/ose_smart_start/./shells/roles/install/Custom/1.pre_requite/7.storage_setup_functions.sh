
# ROUTINES FOR STORAGE
storage_etcd()
{
#######
# ETCD NODE
#######
echo "NOTE: Updating Storage on $HOST"
cat << EOF > do_storage.sh
parted -s /dev/sdb mklabel gpt mkpart pri ext3 2048s 100% set 1 lvm on
pvcreate /dev/sdb1
vgcreate vg_ose /dev/sdb1
lvcreate -y -nlv_etcd -l100%FREE vg_ose
mkfs.xfs -f /dev/mapper/vg_ose-lv_etcd
mkdir /var/lib/etcd
echo "/dev/mapper/vg_ose-lv_etcd /var/lib/etcd xfs defaults 1 2" >> /etc/fstab
mount -a; restorecon -RFvv /var/lib/etcd
EOF
}

storage_compute() {
cat << EOF > do_storage.sh
echo "# Docker Storage Configuration" > /etc/sysconfig/docker-storage-setup
echo "DEVS=/dev/sdb" >> /etc/sysconfig/docker-storage-setup
echo "VG=docker-vg" >> /etc/sysconfig/docker-storage-setup
echo "SETUP_LVM_THIN_POOL=yes" >> /etc/sysconfig/docker-storage-setup
EOF
}

storage_master()
{
# OpenShift Storage followed by Docker
cat << EOF > do_storage.sh
parted -s /dev/sdb mklabel gpt mkpart pri ext3 2048s 40% set 1 lvm on
pvcreate /dev/sdb1
vgcreate vg_ose /dev/sdb1
lvcreate -y -nlv_openshift -l100%FREE vg_ose
mkfs.xfs -f /dev/mapper/vg_ose-lv_openshift
echo "/dev/mapper/vg_ose-lv_openshift 	/var/lib/openshift xfs defaults 1 2" >> /etc/fstab
mkdir /var/lib/openshift
mount -a; restorecon -RFvv /var/lib/openshift

# Docker Storage
parted -s /dev/sdb mkpart pri ext3 40% 100%
echo "# Docker Storage Configuration" > /etc/sysconfig/docker-storage-setup
echo "VG=docker-vg" >> /etc/sysconfig/docker-storage-setup
pvcreate /dev/sdb2
vgcreate docker-vg /dev/sdb2
EOF
}
